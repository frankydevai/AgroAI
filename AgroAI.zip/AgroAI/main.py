from flask import Flask, request, render_template

import pickle
import pandas as pd


app = Flask(__name__)

@app.route('/', methods =["GET", "POST"])
def home():

    return render_template('t.html')


@app.route('/osimliklar', methods=["GET", "POST"])
def osimliklar():

    return render_template("osimlik.html")
@app.route('/muomalar')
def muommalar():

    return render_template('muomma.html')


@app.route('/sugorish', methods=['GET', "POST"])
def sugorish():

    return render_template('calculate.html')
@app.route('/calculate', methods=["POST"])
def calculate():
    data = {
        "n": [float(request.form.get("n"))],
        "p" :  [float(request.form.get("p"))],
        "k": [float(request.form.get("k"))],
        "harorat":[float(request.form.get("harorat"))],
        "namlik": [float(request.form.get("namlik"))],
        "bali ": [float(request.form.get("bal"))],
            "yogingarchilik": [float(request.form.get("yogingarchilik"))],
        "yosh ": [float(request.form.get("yosh"))]}
    df = pd.DataFrame(data=data)
    print(df)
    with open('model.sav', 'rb') as f:
        my_model = pickle.load(f)
    print(my_model.score)
    result = my_model.predict(df)
    result = round(result[0] / 1000)
    return render_template('predict.html', data = result)




if __name__ == '__main__':
  app.run(debug=True)

